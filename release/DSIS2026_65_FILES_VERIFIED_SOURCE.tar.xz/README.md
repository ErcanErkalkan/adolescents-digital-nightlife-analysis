# Adolescents Digital Nightlife — DSIS 2026 reproducibility source

See DSIS2026_REPRO_STATUS.md, README_TR.md and the dsis2026/ directory. Official study data: https://doi.org/10.21942/uva.26395903.v2.

This software-only distribution does not include the official source CSVs or participant-level processed data.
