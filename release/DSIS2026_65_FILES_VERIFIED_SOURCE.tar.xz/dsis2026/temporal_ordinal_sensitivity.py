"""Post-hoc (not preregistered) ordinal and AR(1) GEE sensitivities.

Example: python dsis2026/temporal_ordinal_sensitivity.py \
  --daily data_processed/daily_analytic.csv --output dsis2026/results/temporal_ordinal_sensitivity.json

Input must be derived from the official Figshare Version 2 files.
Do not use synthetic data as empirical evidence.
"""
import argparse
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.genmod.generalized_estimating_equations import OrdinalGEE

TERMS = (
    'daytime_use_within', 'daytime_use_between',
    'prebed_use_within', 'prebed_use_between',
    'postbed_use_within', 'postbed_use_between', 'day',
)


def analyze(daily_file: Path, output: Path) -> dict:
    df = pd.read_csv(daily_file)
    required = ['participant_id', 'day', 'sleep_quality'] + [x for x in TERMS if x != 'day']
    data = df[required].dropna().copy().sort_values(['participant_id', 'day']).reset_index(drop=True)
    if len(data) != 1806 or data.participant_id.nunique() != 155:
        raise ValueError('Unexpected dataset/sample version; verify official source before analysis')
    x = pd.DataFrame(index=data.index)
    for term in TERMS:
        vals = data[term].astype(float)
        sd = vals.std(ddof=0)
        if not np.isfinite(sd) or sd <= 0:
            raise ValueError('Undefined standard deviation: ' + term)
        x['z_' + term] = (vals - vals.mean()) / sd
    groups = data.participant_id.to_numpy()
    y = data.sleep_quality.to_numpy()
    result = {'analysis_type': 'exploratory_posthoc', 'n': len(data),
              'n_participants': int(data.participant_id.nunique()),
              'term': 'z_postbed_use_within'}
    with warnings.catch_warnings(record=True) as notices:
        warnings.simplefilter('always')
        gee = sm.GEE(y, sm.add_constant(x), groups=groups,
                     time=data[['day']].to_numpy(),
                     cov_struct=sm.cov_struct.Autoregressive(grid=True),
                     family=sm.families.Gaussian()).fit(maxiter=120)
    term = result['term']
    result['ar1_gaussian_gee'] = {'converged': bool(gee.converged),
        'estimate': float(gee.params.loc[term]), 'standard_error': float(gee.bse.loc[term]),
        'p': float(gee.pvalues.loc[term]),
        'ci_low': float(gee.conf_int().loc[term, 0]),
        'ci_high': float(gee.conf_int().loc[term, 1]),
        'warnings': [str(w.message) for w in notices]}
    if not all(float(i).is_integer() for i in y) or np.min(y) < 1 or np.max(y) > 7:
        raise ValueError('Expected ordinal outcome scale 1..7')
    with warnings.catch_warnings(record=True) as notices:
        warnings.simplefilter('always')
        ordinal = OrdinalGEE(y.astype(int), x, groups=groups,
                  cov_struct=sm.cov_struct.Exchangeable()).fit(maxiter=150)
    if term not in ordinal.model.exog_names:
        raise ValueError('Target coefficient not identifiable')
    result['ordinal_exchangeable_gee'] = {'converged': bool(ordinal.converged),
        'estimate_log_odds': float(ordinal.params.loc[term]),
        'standard_error': float(ordinal.bse.loc[term]),
        'p': float(ordinal.pvalues.loc[term]),
        'ci_low': float(ordinal.conf_int().loc[term, 0]),
        'ci_high': float(ordinal.conf_int().loc[term, 1]),
        'warnings': [str(w.message) for w in notices]}
    output.parent.mkdir(exist_ok=True, parents=True)
    output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--daily', type=Path, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    print(json.dumps(analyze(args.daily, args.output), indent=2))
