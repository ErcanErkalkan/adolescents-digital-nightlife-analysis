"""Post-hoc matched-sample restriction-vs-lag model check.

Run from repository root after creating data_processed/daily_analytic.csv
from official Figshare v2 data:
  python dsis2026/matched_sample_lag_sensitivity.py
Output: aggregate-only JSON written under dsis2026/results/.
"""
import json
import sys
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from run_analysis import fit_one_repeated_model, repeated_model_specifications  # noqa: E402


def run():
    d = pd.read_csv(ROOT / 'data_processed/daily_analytic.csv')
    terms = repeated_model_specifications(d)['primary_temporal']
    on_exact_lag = d.loc[d['sleep_quality_lag1_exact'].notna()].copy()
    rows0, _, info0 = fit_one_repeated_model(on_exact_lag, 'matched_unlagged', terms)
    rows1, _, info1 = fit_one_repeated_model(on_exact_lag, 'matched_lag_adjusted', terms + ['sleep_quality_lag1_exact'])
    if info0.get('status') != 'fitted' or info1.get('status') != 'fitted':
        raise RuntimeError('Matched model failed; no result should be reported')
    output = {'analysis_type':'exploratory_posthoc', 'same_estimation_sample':True, 'n':int(info0['n_rows']), 'participants':int(info0['n_participants'])}
    if info0['n_rows'] != info1['n_rows'] or info0['n_participants'] != info1['n_participants']:
        raise ValueError('Model samples differ; abort non-comparable coefficients')
    for name, rows in [('matched_unlagged',rows0), ('matched_lag_adjusted',rows1)]:
        term = next(x for x in rows if x['term']=='postbed_use_within')
        output[name] = {k:term[k] for k in ('estimate','ci_low','ci_high','p_value','n_rows','n_participants')}
    dest = ROOT/'dsis2026/results/matched_sample_lag_sensitivity.json'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(output,indent=2)+'\n', encoding='utf-8')
    print(json.dumps(output,indent=2))
    return output

if __name__=='__main__':
    run()
